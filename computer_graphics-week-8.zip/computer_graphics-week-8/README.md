# Textures
Texturing and mipmapping
![screen](/imgs/scrn0.png)