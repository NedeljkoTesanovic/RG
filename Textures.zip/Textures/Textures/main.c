/**
 * @file main.c
 * @author Jovan Ivosevic
 * @brief Texturing
 * @version 0.1
 * @date 2022-10-09
 * 
 * Controls:
 * WASD - Movement
 * LEFT, RIGHT, UP and DOWN - Look around
 * I, O - Higher or lower texture interpolation mixing
 * 1-6 - Cycle texture minifying filter
 * 
 * @copyright Copyright (c) 2022
 *
 */
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <stdlib.h>
#include "cglm/cglm.h"
#include "cglm/cam.h"
#include "camera.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

const int WindowWidth = 800;
const int WindowHeight = 800;
const char* WindowTitle = "Textures";
const float TargetFPS = 60.0f;

static void
ErrorCallback(int error, const char* description) {
    fprintf(stderr, "GLFW Error: %s\n", description);
}
static unsigned CompileShader(GLenum type, const char* source);
static unsigned CreateShader(const char* vertexShaderSource, const char* fragmentShaderSource);

int main() {
    GLFWwindow* Window = 0;
    if (!glfwInit()) {
        fprintf(stderr, "Failed to init glfw\n");
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    Window = glfwCreateWindow(WindowWidth, WindowHeight, WindowTitle, 0, 0);
    if (!Window) {
        fprintf(stderr, "Failed to create window\n");
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(Window);

    GLenum GlewError = glewInit();
    if (GlewError != GLEW_OK) {
        fprintf(stderr, "Failed to init glew: %s\n", glewGetErrorString(GlewError));
        glfwTerminate();
        return -1;
    }

    glfwSetErrorCallback(ErrorCallback);

    glViewport(0, 0, WindowWidth, WindowHeight);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);


    int TextureWidth;
    int TextureHeight;
    int TextureChannels;
    unsigned char* ImageData = stbi_load("res/balrog.png", &TextureWidth, &TextureHeight, &TextureChannels, 0);
    // NOTE(Jovan): Images should usually flipped vertically as they are loaded "upside-down"
    stbi__vertical_flip(ImageData, TextureWidth, TextureHeight, TextureChannels);

    unsigned Texture;
    glGenTextures(1, &Texture);
    glBindTexture(GL_TEXTURE_2D, Texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, TextureWidth, TextureHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, ImageData);
    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(ImageData);


    glBindTexture(GL_TEXTURE_2D, Texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    float rectangle[] =
    {
        -0.25, -0.25, 0.0,   1.0, 0.0, 0.0,  0.0, 0.0,
        0.25, -0.25, 0.0,   0.0, 1.0, 0.0,   1.0, 0.0,
        -0.25, 0.25, 0.0,   0.0, 0.0, 1.0,   0.0, 1.0,
        0.25, 0.25, 0.0,    1.0, 1.0, 0.0,   1.0, 1.0,
    };
    unsigned rectangleVAO;
    glGenVertexArrays(1, &rectangleVAO);
    glBindVertexArray(rectangleVAO);
    unsigned rectangleVBO;
    glGenBuffers(1, &rectangleVBO);
    glBindBuffer(GL_ARRAY_BUFFER, rectangleVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(rectangle), rectangle, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    unsigned TexturedProgram = CreateShader("shaders/basic.vert", "shaders/textured.frag");
    glUseProgram(TexturedProgram);
    // NOTE(Jovan): Set texture unit for each sampler
    glUniform1i(glGetUniformLocation(TexturedProgram, "uTexture0"), 0);
    glUseProgram(0);

    glClearColor(0.1f, 0.1f, 0.2f, 0.0f);

    // NOTE(Jovan): Currently used MIN filter
    GLint CurrentFilter = 0;
    // NOTE(Jovan): Level of interpolation for Balrog. 1 - Shows Balrog, - 0 Shows flames
    float Interpolation = 1.0f;

    while (!glfwWindowShouldClose(Window)) {
        glfwPollEvents();
        if (glfwGetKey(Window, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(Window, GLFW_TRUE);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(TexturedProgram);

        glBindVertexArray(rectangleVAO);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, Texture);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        glBindTexture(GL_TEXTURE_2D, 0);

        glBindVertexArray(0);

        glUseProgram(0);

        glfwSwapBuffers(Window);
    }
    glfwTerminate();
    return 0;
}


unsigned CompileShader(GLenum type, const char* source) {
    unsigned int id, result, logLength;
    char* sourceCode = NULL, * errorMessage = NULL;
    long shaderSize;
    FILE* inputFile = 0;

    id = glCreateShader(type);
    inputFile = fopen(source, "r");
    if (!inputFile)
    {
        fprintf(stderr, "ERROR: %s file not found.\n", source);
        return 0;
    }

    fseek(inputFile, 0L, SEEK_END);
    shaderSize = ftell(inputFile);
    fseek(inputFile, 0L, SEEK_SET);
    sourceCode = (char*)calloc(shaderSize, sizeof(char));

    if (!sourceCode) {
        fprintf(stderr, "ERROR: Could not load source code.\n");
        return 0;
    }

    fread(sourceCode, sizeof(char), shaderSize, inputFile);
    fclose(inputFile);

    glShaderSource(id, 1, &sourceCode, NULL);
    glCompileShader(id);

    free(sourceCode);

    glGetShaderiv(id, GL_COMPILE_STATUS, &result);
    if (result == GL_FALSE)
    {
        glGetShaderiv(id, GL_INFO_LOG_LENGTH, &logLength);
        errorMessage = (char*)calloc(logLength, sizeof(char));
        glGetShaderInfoLog(id, logLength, &logLength, errorMessage);
        fprintf(stderr, "ERROR compiling shader: %s\n", errorMessage);
        free(errorMessage);
    }

    return id;
}

unsigned CreateShader(const char* vertexShaderSource, const char* fragmentShaderSource) {
    unsigned int program, vertexShader, fragmentShader;

    program = glCreateProgram();
    vertexShader = CompileShader(GL_VERTEX_SHADER, vertexShaderSource);
    fragmentShader = CompileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);
    glValidateProgram(program);

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return program;
}