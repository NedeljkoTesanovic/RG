/**
 * @file main.cpp
 * @author Jovan Ivosevic
 * @brief Base project for Computer Graphics course
 * @version 0.1
 * @date 2022-10-09
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <chrono>
#include <thread>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <iostream>
#include "shader.hpp"
#include "model.hpp"
#include "renderable.hpp"


const int WindowWidth = 800;
const int WindowHeight = 800;
const std::string WindowTitle = "Base";
const float TargetFPS = 60.0f;
const float TargetFrameTime = 1.0f / TargetFPS;

/**
 * @brief Keyboard callback function for GLFW. See GLFW docs for details
 *
 * @param window GLFW window context object
 * @param key Triggered key GLFW code
 * @param scancode Triggered key scan code
 * @param action Triggered key action: pressed, released or repeated
 * @param mode Modifiers
 */
static void
KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mode) {
    bool IsDown = action == GLFW_PRESS || action == GLFW_REPEAT;
    switch (key) {
        case GLFW_KEY_ESCAPE: glfwSetWindowShouldClose(window, GLFW_TRUE); break;
    }
}

/**
 * @brief Error callback function for GLFW. See GLFW docs for details
 *
 * @param error Error code
 * @param description Error message
 */
static void
ErrorCallback(int error, const char* description) {
    std::cerr << "GLFW Error: " << description << std::endl;
}

int main() {
    GLFWwindow* Window = 0;
    if (!glfwInit()) {
        std::cerr << "Failed to init glfw" << std::endl;
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwSetErrorCallback(ErrorCallback);

    Window = glfwCreateWindow(WindowWidth, WindowHeight, WindowTitle.c_str(), 0, 0);
    if (!Window) {
        std::cerr << "Failed to create window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(Window);
    glfwSetKeyCallback(Window, KeyCallback);

    GLenum GlewError = glewInit();
    if (GlewError != GLEW_OK) {
        std::cerr << "Failed to init glew: " << glewGetErrorString(GlewError) << std::endl;
        glfwTerminate();
        return -1;
    }

    Shader Basic("shaders/basic.vert", "shaders/basic.frag");

    Model Jap("ki61/14082_WWII_Plane_Japan_Kawasaki_Ki-61_v1_L2.obj");
    Jap.Load();

    float cubeVertices[] =
    {
        -0.2, -0.2, -0.2,       1.0, 0.0, 0.0,
        +0.2, -0.2, -0.2,       1.0, 1.0, 0.0,
        -0.2, -0.2, +0.2,       1.0, 1.0, 1.0,
        +0.2, -0.2, +0.2,       1.0, 0.0, 1.0,

        -0.2, +0.2, -0.2,       0.0, 1.0, 1.0,
        +0.2, +0.2, -0.2,       0.0, 1.0, 0.0,
        -0.2, +0.2, +0.2,       0.0, 0.0, 1.0,
        +0.2, +0.2, +0.2,       1.0, 1.0, 1.0,
    };

    unsigned int cubeIndices[] = {
        0, 1, 3,
        0, 2, 3,

        4, 6, 7,
        4, 5, 7,

        3, 6, 2,
        3, 6, 7,

        0, 4, 1,
        1, 4, 5,

        0, 6, 2,
        0, 4, 6,

        1, 3, 7,
        1, 7, 5
    };

    float orangeCubeVertices[] =
    {
        -0.2, -0.2, -0.2,       1.0, 0.5, 0.0,
        +0.2, -0.2, -0.2,       1.0, 0.5, 0.0,
        -0.2, -0.2, +0.2,       1.0, 0.5, 0.0,
        +0.2, -0.2, +0.2,       1.0, 0.5, 0.0,

        -0.2, +0.2, -0.2,       1.0, 0.5, 0.0,
        +0.2, +0.2, -0.2,       1.0, 0.5, 0.0,
        -0.2, +0.2, +0.2,       1.0, 0.5, 0.0,
        +0.2, +0.2, +0.2,       1.0, 0.5, 0.0,
    };
    float yellowCubeVertices[] =
    {
        -0.2, -0.2, -0.2,       1.0, 1.0, 0.0,
        +0.2, -0.2, -0.2,       1.0, 1.0, 0.0,
        -0.2, -0.2, +0.2,       1.0, 1.0, 0.0,
        +0.2, -0.2, +0.2,       1.0, 1.0, 0.0,

        -0.2, +0.2, -0.2,       1.0, 1.0, 0.0,
        +0.2, +0.2, -0.2,       1.0, 1.0, 0.0,
        -0.2, +0.2, +0.2,       1.0, 1.0, 0.0,
        +0.2, +0.2, +0.2,       1.0, 1.0, 0.0,
    };

    float cloudCubeVertices[] =
    {
        -0.2, -0.2, -0.2,       0.9, 0.9, 1.0,
        +0.2, -0.2, -0.2,       1.0, 1.0, 1.0,
        -0.2, -0.2, +0.2,       0.9, 0.9, 1.0,
        +0.2, -0.2, +0.2,       1.0, 1.0, 1.0,

        -0.2, +0.2, -0.2,       0.9, 0.9, 1.0,
        +0.2, +0.2, -0.2,       0.9, 0.9, 1.0,
        -0.2, +0.2, +0.2,       1.0, 1.0, 1.0,
        +0.2, +0.2, +0.2,       1.0, 1.0, 1.0,
    };



    Renderable cube(cubeVertices, sizeof(cubeVertices), cubeIndices, sizeof(cubeIndices));
    Renderable sunCube1(orangeCubeVertices, sizeof(orangeCubeVertices), cubeIndices, sizeof(cubeIndices));
    Renderable sunCube2(yellowCubeVertices, sizeof(yellowCubeVertices), cubeIndices, sizeof(cubeIndices));
    Renderable cloud(cloudCubeVertices, sizeof(cloudCubeVertices), cubeIndices, sizeof(cubeIndices));

    glm::mat4 v = glm::lookAt(glm::vec3(0.0, 0.0, -2.0), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
    glm::mat4 p = glm::perspective(glm::radians(100.0f), 1.0f, 0.1f, 100.0f);

    float angle = 0;
    float movement = 0;

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0, 0.3, 1.0, 1.0);

    // NOTE(Jovan): Time-keeping
    float FrameStartTime = glfwGetTime();
    float FrameEndTime = glfwGetTime();
    float dt = FrameEndTime - FrameStartTime;
    while (!glfwWindowShouldClose(Window)) {
        glfwPollEvents();
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        FrameStartTime = glfwGetTime();
        glUseProgram(Basic.GetId());
        // TODO(Jovan): Draw code goes here
        glUniform1f(glGetUniformLocation(Basic.GetId(), "offset"), 1.0f);
        Basic.SetProjection(p);
        Basic.SetView(v);

        //Plane
        glm::mat4 m(1.0f);
        m = glm::scale(m, glm::vec3(0.25, 0.25, 0.25));
        m = glm::rotate(m, glm::radians(90.0f), glm::vec3(-1.0, 0.0, 0.0));
        m = glm::rotate(m, glm::radians(90.0f), glm::vec3(0.0, 0.0, 1.0));
        m = glm::rotate(m, glm::radians(++angle), glm::vec3(1.0, 0.0, 0.01));        
        m = glm::translate(m, glm::vec3(0.5, 1.75, +0.5));
        movement += 0.1;
        if (movement > 10.0)
            movement = -10.0;
        m = glm::translate(m, glm::vec3(movement, 0.0, 0.0));
        Basic.SetModel(m);
        Jap.Render();


        //Funky cube
      //  m = glm::mat4(1.0f);
      //  m = glm::rotate(m, glm::radians(++angle), glm::vec3(1.0, 1.0, 1.0));
      //  Basic.SetModel(m);
      //  cube.Render();

        //Clouds

        m = glm::mat4(1.0f);
        m = glm::scale(m, glm::vec3(2.0, 1.0, -1.0));
        m = glm::translate(m, glm::vec3(-0.70, 4.7, -3.0));
        Basic.SetModel(m);
        cloud.Render();
        m = glm::mat4(1.0f);
        m = glm::translate(m, glm::vec3(2.00, 1.0, 1.0));
        Basic.SetModel(m);
        cloud.Render();
        m = glm::mat4(1.0f);
        m = glm::translate(m, glm::vec3(-0.3, -1.7, 0.1));
        Basic.SetModel(m);
        cloud.Render();
        m = glm::mat4(1.0f);
        m = glm::translate(m, glm::vec3(-1.6, -0.5, 1.0));
        Basic.SetModel(m);
        cloud.Render();
        m = glm::mat4(1.0f);
        m = glm::translate(m, glm::vec3(-2, -1.4, -1.5));
        Basic.SetModel(m);
        cloud.Render();
        m = glm::mat4(1.0f);
        m = glm::translate(m, glm::vec3(1.1, -1.2, -0.15));
        Basic.SetModel(m);
        cloud.Render();


        //Sun
        m = glm::mat4(1.0f);

        m = glm::scale(m, glm::vec3(abs(sin(glfwGetTime())) / 2 + 0.5));
        m = glm::rotate(m, glm::radians(angle), glm::vec3(1.0, 1.0, 1.0));
        Basic.SetModel(m);
        sunCube1.Render();
        m = glm::rotate(m, glm::radians(45.0f), glm::vec3(1.0, 1.0, 1.0));
        Basic.SetModel(m);
        glUniform1f(glGetUniformLocation(Basic.GetId(), "offset"), abs(sin(glfwGetTime())));
        sunCube2.Render();
        glUniform1f(glGetUniformLocation(Basic.GetId(), "offset"), 1.0f);

        glUseProgram(0);
        glfwSwapBuffers(Window);

        // NOTE(Jovan): Frame stabilization
        FrameEndTime = glfwGetTime();
        dt = FrameEndTime - FrameStartTime;
        if (dt < TargetFPS) {
            int DeltaMS = (int)((TargetFrameTime - dt) * 1e3f);
            std::this_thread::sleep_for(std::chrono::milliseconds(DeltaMS));
            FrameEndTime = glfwGetTime();
        }
        dt = FrameEndTime - FrameStartTime;
    }

    glfwTerminate();
    return 0;
}



